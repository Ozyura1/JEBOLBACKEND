<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Seed an initial SUPER_ADMIN
        $this->call([
            \Database\Seeders\SuperAdminSeeder::class,
            \Database\Seeders\AdminPerkawinanSeeder::class,
            \Database\Seeders\AdminKtpSeeder::class,
            \Database\Seeders\AdminIkdSeeder::class,
            \Database\Seeders\RtSeeder::class,
        ]);
    }
}
